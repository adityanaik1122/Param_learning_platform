﻿namespace PrintMessage
{
    /// <summary>
    /// Prints a message to the console
    /// </summary>

    internal class Program
    {
        /// <summary>
        /// Prints the message
        /// </summary>
        /// <param name="args">command-line arguments</param>
        static void Main(string[] args)
        {
            Message rainMessage = new Message("Hello, world\n" +
                "Chinese Democracy is done and it's November\n" +
                "Is it raining?");
            rainMessage.Print();
        }
    }
}