﻿using System;

namespace PrintMessage
{
    /// <summary>
    /// A message
    /// </summary>
    public class Message
    {
        #region Fields

        string message;

        #endregion

        #region Constructors

        /// <summary>
        /// Constructs an object with the given message
        /// </summary>
        /// <param name="message">the message</param>
        public Message(string message)
        {
            this.message = message;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Prints the message
        /// </summary>
        public void Print()
        {
            Console.WriteLine(message);
        }

        #endregion
    }
}