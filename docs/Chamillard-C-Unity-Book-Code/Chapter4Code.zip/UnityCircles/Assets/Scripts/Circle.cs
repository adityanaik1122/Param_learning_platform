﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// A circle
/// </summary>
public class Circle : MonoBehaviour
{
	// use [SerializeField] so we can change in the Inspector
	[SerializeField]
	int radius;
	float area;

    /// <summary>
    /// Start is called before the first frame update
    /// </summary>
    void Start()
    {
		// calculate area
		// note that we're using UnityEngine Mathf instead of System Math
		area = Mathf.PI * Mathf.Pow(radius, 2);

		// scale circle sprite based on radius
		Vector3 scale = transform.localScale;
		scale.x *= radius;
		scale.y *= radius;
		transform.localScale = scale;

		// print radius and area
		Debug.Log("Radius: " + radius +
		      ", Area: " + area);
	}
}
