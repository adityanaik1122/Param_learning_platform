﻿using System;

namespace ShowCards
{
    /// <summary>
    /// Creates and shows playing cards
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Creates and shows the cards
        /// </summary>
        /// <param name="args">comand-line args</param>
        static void Main(string[] args)
        {
            // create the cards
            Card firstCard = new Card("Ace", "Spades");
            Card secondCard = new Card("Jack", "Diamonds");
            Card thirdCard = new Card("Queen", "Hearts");

            // print the cards in reverse order
            Console.WriteLine(thirdCard.Rank + " of " + thirdCard.Suit);
            Console.WriteLine(secondCard.Rank + " of " + secondCard.Suit);
            Console.WriteLine(firstCard.Rank + " of " + firstCard.Suit);
        }
    }
}