﻿using System;

namespace CirclesApplication
{
    /// <summary>
    /// A circle
    /// </summary>
    public class Circle
    {
        int radius;
        float area;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="radius">the radius of the circle</param>
        public Circle(int radius)
        {
            this.radius = radius;
            area = MathF.PI * MathF.Pow(radius, 2);
        }

        /// <summary>
        /// Gets the radius of the circle
        /// </summary>
        public int Radius
        {
            get { return radius; }
        }

        /// <summary>
        /// Gets the area of the circle
        /// </summary>
        public float Area
        {
            get { return area; }
        }
    }
}