﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// A playing card
/// </summary>
public class Card : MonoBehaviour
{
	#region Fields

	// card sprites
	[SerializeField]
	Sprite faceUpSprite;
	[SerializeField]
	Sprite faceDownSprite;

	// other card state
	[SerializeField]
	string rank;	
	[SerializeField]
	string suit;
	[SerializeField]
	bool faceUp;

	// saved for efficiency
	SpriteRenderer spriteRenderer;

	#endregion

	#region Properties

	/// <summary>
	/// Gets the card rank
	/// </summary>
	public string Rank
    {
		get { return rank; }
	}

	/// <summary>
	/// Gets the card suit
	/// </summary>
	public string Suit
    {
		get { return suit; }
	}

	/// <summary>
	/// Gets whether or not the card is face up
	/// </summary>
	public bool FaceUp
    {
		get { return faceUp; }
	}

    #endregion

    #region Methods

    /// <summary>
    /// Start is called before the first frame update
    /// </summary>
    void Start()
    {
		// save sprite renderer in a field for efficiency
		spriteRenderer = GetComponent<SpriteRenderer>();

		// set appropriate sprite
		SetSprite();
	}

	/// <summary>
	/// Flips the card over
	/// </summary>
	public void FlipOver()
    {
		faceUp = !faceUp;

		// set appropriate sprite
		SetSprite();
	}

	/// <summary>
	/// Sets the sprite
	/// </summary>
	void SetSprite()
    {
		// set appropriate sprite
		if (faceUp)
        {
			spriteRenderer.sprite = faceUpSprite;
		}
        else
        {
			spriteRenderer.sprite = faceDownSprite;
		}
	}
	
	#endregion
}
