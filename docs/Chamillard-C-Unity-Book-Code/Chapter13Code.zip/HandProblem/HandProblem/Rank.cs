namespace HandProblem
{	
	/// <summary>
	/// An enumeration for card ranks
	/// </summary>
	public enum Rank
    {
		Ace,
		Two,
		Three,
		Four,
		Five,
		Six,
		Seven,
		Eight,
		Nine,
		Ten,
		Jack,
		Queen,
		King
	}
}
