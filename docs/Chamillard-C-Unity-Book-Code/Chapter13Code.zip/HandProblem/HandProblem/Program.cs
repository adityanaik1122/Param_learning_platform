﻿using System;

namespace HandProblem
{
    /// <summary>
    /// Tests the Hand class
    /// </summary>

    internal class Program
    {
        /// <summary>
        /// Tests the Hand class
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            Hand hand;

            // Test Case 1
            Console.WriteLine("Test Case 1");
            Console.WriteLine("-----------");
            hand = new Hand();
            PrintEmpty(hand);
            Console.WriteLine("Size: " + hand.Count);
            Console.WriteLine();

            // Test Case 2
            Console.WriteLine("Test Case 2");
            Console.WriteLine("-----------");
            hand = new Hand();
            hand.AddCard(new Card(Rank.Ace, Suit.Spades));
            hand.AddCard(new Card(Rank.Queen, Suit.Hearts));
            for (int i = 0; i < hand.Count; i++)
            {
                hand.GetCard(i).Print();
            }
            PrintEmpty(hand);
            Console.WriteLine("Size: " + hand.Count);
            Console.WriteLine();

            // Test Case 3
            Console.WriteLine("Test Case 3");
            Console.WriteLine("-----------");
            hand = new Hand();
            Card card = hand.GetCard(0);
            PrintLocationValidity(card, "getting a card");
            Console.WriteLine();

            // Test Case 4
            Console.WriteLine("Test Case 4");
            Console.WriteLine("-----------");
            hand = new Hand();
            hand.AddCard(new Card(Rank.Ace, Suit.Spades));
            hand.AddCard(new Card(Rank.Queen, Suit.Hearts));
            hand.AddCard(new Card(Rank.Jack, Suit.Clubs));
            hand.RemoveCard(2).Print();
            hand.RemoveCard(0).Print();
            hand.RemoveCard(0).Print();
            card = hand.RemoveCard(0);
            PrintLocationValidity(card, "removing a card");
        }

        /// <summary>
        /// Prints whether or not the given hand is empty
        /// </summary>
        /// <param name="hand">the hand to check</param>
        static void PrintEmpty(Hand hand)
        {
            if (hand.Empty)
            {
                Console.WriteLine("The hand is empty");
            }
            else
            {
                Console.WriteLine("The hand is not empty");
            }
        }

        /// <summary>
        /// Prints whether the location was valid for the given operation
        /// </summary>
        /// <param name="card">the card returned by the method</param>
        /// <param name="operation">the operation that was performed</param>
        static void PrintLocationValidity(Card card, string operation)
        {
            if (card != null)
            {
                Console.WriteLine("Location for " + operation + " was invalid");
            }
            else
            {
                Console.WriteLine("Location for " + operation + " was invalid");
            }
        }
    }
}