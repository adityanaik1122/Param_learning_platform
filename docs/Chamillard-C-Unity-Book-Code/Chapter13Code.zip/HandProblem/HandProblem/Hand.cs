using System.Collections.Generic;

namespace HandProblem
{	
	/// <summary>
	/// A hand of cards
	/// </summary>
	public class Hand
    {		
		#region Fields
		
		List<Card> cards = new List<Card>();
		
		#endregion
		
		#region Constructors
		
		/// <summary>
		/// Constructor
		/// </summary>
		public Hand()
        {
		}
		
		#endregion
		
		#region Properties
		
		/// <summary>
		/// Gets the number of cards in the hand
		/// </summary>
		public int Count
        {
			get { return cards.Count; }
		}
		
		/// <summary>
		/// Gets whether or not the hand is empty
		/// </summary>
		public bool Empty
        {
			get { return cards.Count == 0; }
		}
		
		#endregion
		
		#region Public methods
		
		/// <summary>
		/// Gets the card at the given location (leaving the card in the hand)
		/// </summary>
		/// <param name="location">the 0-based location of the card</param>
		/// <returns>the card or null if the location is invalid</returns>
		public Card GetCard(int location)
        {			
			// check for valid location
			if (ValidLocation(location))
            {
				return cards[location];
			}
            else
            {				
				// invalid location
				return null;
			}
		}
		
		/// <summary>
		/// Adds the given card to the hand
		/// </summary>
		/// <param name="card">the card to add</param>
		public void AddCard(Card card)
        {
			cards.Add(card);
		}
		
		/// <summary>
		/// Removes the card from the given location in the hand
		/// </summary>
		/// <param name="location">the 0-based location of the card</param>
		/// <returns>the card or null if the location is invalid</returns>
		public Card RemoveCard(int location)
        {			
			// check for valid location
			if (ValidLocation(location))
            {
				Card card = cards[location];
				cards.RemoveAt(location);
				return card;
			}
            else
            {				
				// invalid location
				return null;
			}
		}
		
		#endregion
		
		#region Private methods
		
		/// <summary>
		/// Tells whether or not the given location is valid
		/// </summary>
		/// <param name="location">the location</param>
		/// <returns>true if the location is valid, false otherwise</returns>
		bool ValidLocation(int location)
        {
			return location >= 0 && location < cards.Count;
		}
		
		#endregion
	}
}
