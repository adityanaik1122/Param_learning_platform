﻿using System;

namespace RefactoredCards
{
    /// <summary>
    /// Application class to test refactored Card class
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Tests refactored Card class
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            Card[] hand = new Card[5];

            // fill hand with cards
            hand[0] = new Card(Rank.Ten, Suit.Spades);
            hand[1] = new Card(Rank.Jack, Suit.Spades);
            hand[2] = new Card(Rank.Queen, Suit.Spades);
            hand[3] = new Card(Rank.King, Suit.Spades);
            hand[4] = new Card(Rank.Ace, Suit.Spades);

            // test rank and suit
            Console.WriteLine(hand[0].Rank + " of " + hand[0].Suit);
            Console.WriteLine(hand[1].Rank + " of " + hand[1].Suit);
            Console.WriteLine(hand[2].Rank + " of " + hand[2].Suit);
            Console.WriteLine(hand[3].Rank + " of " + hand[3].Suit);
            Console.WriteLine(hand[4].Rank + " of " + hand[4].Suit);
        }
    }
}