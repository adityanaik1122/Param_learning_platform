﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Prints circle information
/// </summary>
public class PrintCircleInformation : MonoBehaviour
{
	/// <summary>
	/// Use this for initialization
	/// </summary>
	void Start()
	{
        int radius;
        float area;

        // circle with radius 0
        radius = 0;
        area = Mathf.PI * radius * radius;
        Debug.Log("Radius: " + radius + " Area: " + area);

        // circle with radius 1
        radius = 1;
        area = Mathf.PI * radius * radius;
        Debug.Log("Radius: " + radius + " Area: " + area);

        // circle with radius 2
        radius = 2;
        area = Mathf.PI * radius * radius;
        Debug.Log("Radius: " + radius + " Area: " + area);

        // circle with radius 3
        radius = 3;
        area = Mathf.PI * radius * radius;
        Debug.Log("Radius: " + radius + " Area: " + area);

        // circle with radius 4
        radius = 4;
        area = Mathf.PI * radius * radius;
        Debug.Log("Radius: " + radius + " Area: " + area);

        // circle with radius 5
        radius = 5;
        area = Mathf.PI * radius * radius;
        Debug.Log("Radius: " + radius + " Area: " + area);
    }
}
