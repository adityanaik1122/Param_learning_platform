﻿using System;

namespace CirclesApplication
{
    /// <summary>
    /// Outputs a variety of circle characteristics
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Outputs radius and area for circles with radii 0 through 5
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            int radius;
            float area;

            // circle with radius 0
            radius = 0;
            area = MathF.PI * radius * radius;
            Console.WriteLine("Radius: {0}, Area: {1:N2}", 
                radius, area);

            // circle with radius 1
            radius = 1;
            area = MathF.PI * radius * radius;
            Console.WriteLine("Radius: {0}, Area: {1:N2}",
                radius, area);

            // circle with radius 2
            radius = 2;
            area = MathF.PI * radius * radius;
            Console.WriteLine("Radius: {0}, Area: {1:N2}",
                radius, area);

            // circle with radius 3
            radius = 3;
            area = MathF.PI * radius * radius;
            Console.WriteLine("Radius: {0}, Area: {1:N2}",
                radius, area);

            // circle with radius 4
            radius = 4;
            area = MathF.PI * radius * radius;
            Console.WriteLine("Radius: {0}, Area: {1:N2}",
                radius, area);

            // circle with radius 5
            radius = 5;
            area = MathF.PI * radius * radius;
            Console.WriteLine("Radius: {0}, Area: {1:N2}",
                radius, area);
        }
    }
}