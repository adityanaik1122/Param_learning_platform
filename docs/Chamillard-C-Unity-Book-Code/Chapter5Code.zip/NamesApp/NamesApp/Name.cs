namespace NamesApp
{
	/// <summary>
	/// Stores information about a name
	/// </summary>
	public class Name
    {
		#region Fields
		
		string firstName;
		char middleInitial;
		string lastName;
		
		#endregion
		
		#region Constructors
		
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="fullName">full name</param>
		public Name(string fullName)
        {
			// extract parts from full name
			int firstSpaceLocation = fullName.IndexOf(' ');
			firstName = fullName.Substring(0, firstSpaceLocation);
			middleInitial = fullName[firstSpaceLocation + 1];
			lastName = fullName.Substring(fullName.LastIndexOf(' ') + 1);
		}
		
		#endregion
		
		#region Properties
		
		/// <summary>
		/// Gets the first name
		/// </summary>
		public string FirstName
        {
			get { return firstName; }
		}
		
		/// <summary>
		/// Gets the middle initial
		/// </summary>
		public char MiddleInitial
        {
			get { return middleInitial; }
		}
		
		/// <summary>
		/// Gets the last name
		/// </summary>
		public string LastName
        {
			get { return lastName; }
		}
		
		/// <summary>
		/// Gets whether or not the last name is hyphenated
		/// </summary>
		public bool Hyphenated
        {
			get { return lastName.IndexOf('-') != -1; }
		}
		
		#endregion
	}
}
