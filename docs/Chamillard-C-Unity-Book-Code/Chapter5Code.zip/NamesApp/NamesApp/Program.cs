﻿using System;

namespace NamesApp
{
    /// <summary>
    /// Prints out information about three names
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Prints name info
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            Name name0;
            Name name1;
            Name name2;

            // read names and create name objects
            Console.Write("Enter Name 1 (firstname mi. lastname): ");
            name0 = new Name(Console.ReadLine());
            Console.Write("Enter Name 2 (firstname mi. lastname): ");
            name1 = new Name(Console.ReadLine());
            Console.Write("Enter Name 3 (firstname mi. lastname): ");
            name2 = new Name(Console.ReadLine());
            Console.WriteLine();

            // display name info
            Console.WriteLine("{0}, {1} {2}.", name0.LastName, 
                name0.FirstName, name0.MiddleInitial);
            Console.WriteLine("{0}, {1} {2}.", name1.LastName, 
                name1.FirstName, name1.MiddleInitial);
            Console.WriteLine("{0}, {1} {2}.", name2.LastName, 
                name2.FirstName, name2.MiddleInitial);

            // display hyphenated info
            Console.WriteLine("{0}, Hyphenated: {1}", name0.LastName, 
                name0.Hyphenated);
            Console.WriteLine("{0}, Hyphenated: {1}", name1.LastName, 
                name1.Hyphenated);
            Console.WriteLine("{0}, Hyphenated: {1}", name2.LastName, 
                name2.Hyphenated);
        }
    }
}