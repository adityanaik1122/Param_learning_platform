﻿using System;
using System.Collections.Generic;

namespace InactiveStringSearch
{
    /// <summary>
    /// A class to search for an Inactive string
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Searches for an Inactive string
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            // Test Case 1
            List<string> strings = new List<string>();
            strings.Add("hey");
            strings.Add("hi");
            strings.Add("yo");
            int index = FindInactiveStringLocation(0, strings);
            if (index == -1)
            {
                Console.WriteLine("Test Case 1 passed");
            }
            else
            {
                Console.WriteLine("TEST CASE 1 FAILED!!");
            }

            // Test Case 2
            strings.Clear();
            strings.Add("hey");
            strings.Add("hi");
            strings.Add("inactive");
            index = FindInactiveStringLocation(1, strings);
            if (index == 2)
            {
                Console.WriteLine("Test Case 2 passed");
            }
            else
            {
                Console.WriteLine("TEST CASE 2 FAILED!!");
            }

            // Test Case 3
            strings.Clear();
            strings.Add("inactive");
            strings.Add("hey");
            strings.Add("hi");
            strings.Add("yo");
            index = FindInactiveStringLocation(1, strings);
            if (index == 0)
            {
                Console.WriteLine("Test Case 3 passed");
            }
            else
            {
                Console.WriteLine("TEST CASE 3 FAILED!!");
            }

            // Test Case 4
            strings.Clear();
            strings.Add("hey");
            strings.Add("inactive");
            strings.Add("hi");
            strings.Add("yo");
            index = FindInactiveStringLocation(1, strings);
            if (index == 1)
            {
                Console.WriteLine("Test Case 4 passed");
            }
            else
            {
                Console.WriteLine("TEST CASE 4 FAILED!!");
            }

            // Test Case 5
            strings.Clear();
            strings.Add("hey");
            strings.Add("inactive");
            strings.Add("hi");
            strings.Add("yo");
            index = FindInactiveStringLocation(3, strings);
            if (index == 1)
            {
                Console.WriteLine("Test Case 5 passed");
            }
            else
            {
                Console.WriteLine("TEST CASE 5 FAILED!!");
            }

            Console.WriteLine();
        }

        /// <summary>
        /// Finds the index of the first occurrence of "inactive" in the list of strings,
        /// starting at the provided index + 1. Checks all strings in the list, wrapping
        /// around to the beginning of the list if necessary. Returns -1 if "inactive" 
        /// doesn't occur in the list
        /// </summary>
        /// <param name="startIndex">the start index</param>
        /// <param name="strings">the list of strings</param>
        /// <returns>the index of the "inactive" string or -1</returns>
        static int FindInactiveStringLocation(int startIndex, List<string> strings)
        {
            // initialize search variables
            int inactiveIndex = -1;
            int i = startIndex + 1;
            if (i >= strings.Count)
            {
                i = 0;
            }
            bool searchComplete = false;

            while (!searchComplete)
            {
                // check for and save inactive string info
                if (strings[i] == "inactive")
                {
                    inactiveIndex = i;
                    searchComplete = true;
                }

                // check for end of search
                if (i == startIndex)
                {
                    searchComplete = true;
                }
                else
                {
                    // move along list, wrapping if necessary
                    i++;
                    if (i >= strings.Count)
                    {
                        i = 0;
                    }
                }
            }

            return inactiveIndex;
        }
    }
}