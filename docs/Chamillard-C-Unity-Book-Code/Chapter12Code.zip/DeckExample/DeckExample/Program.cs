﻿using System;

namespace DeckExample
{
    /// <summary>
    /// Tests the Deck class
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Tests the Deck class
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            // create and print deck
            Deck deck = new Deck();
            deck.Print();

            // check IsEmpty property for non-empty deck
            Console.WriteLine();
            if (deck.Empty)
            {
                Console.WriteLine("Deck is empty");
            }
            else
            {
                Console.WriteLine("Deck isn't empty");
            }

            // check cut
            Console.WriteLine();
            Console.WriteLine("Deck after cut at 2:");
            deck.Cut(2);
            deck.Print();

            // check taking top card
            Console.WriteLine();
            Card topCard = deck.TakeTopCard();
            Console.WriteLine("Top card was : " + topCard.Rank + " of " + topCard.Suit);

            // check shuffle
            Console.WriteLine();
            Console.WriteLine("Deck after shuffling:");
            deck.Shuffle();
            deck.Print();

            // check IsEmpty property for empty deck
            Console.WriteLine();
            while (!deck.Empty)
            {
                deck.TakeTopCard();
            }
            if (deck.Empty)
            {
                Console.WriteLine("Deck is empty");
            }
            else
            {
                Console.WriteLine("Deck isn't empty");
            }
        }
    }
}
