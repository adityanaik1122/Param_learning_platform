﻿using System;

namespace DieProblem
{
    /// <summary>
    /// Tests the Die class
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Executes test cases for the Die class
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            #region Test Case 1

            Die die1 = new Die();
            Console.WriteLine("Test Case 1");
            Console.WriteLine("-----------");
            Console.WriteLine("Top Side: " + die1.TopSide);
            Console.WriteLine("Num Sides: " + die1.NumSides);
            die1.Roll();
            Console.WriteLine("Top Side After Roll: " + die1.TopSide);
            die1.Roll();
            Console.WriteLine("Top Side After Roll: " + die1.TopSide);
            die1.Roll();
            Console.WriteLine("Top Side After Roll: " + die1.TopSide);
            Console.WriteLine();

            #endregion

            #region Test Case 2

            Die die2 = new Die(256);
            Console.WriteLine("Test Case 2");
            Console.WriteLine("-----------");
            Console.WriteLine("Top Side: " + die2.TopSide);
            Console.WriteLine("Num Sides: " + die2.NumSides);
            die2.Roll();
            Console.WriteLine("Top Side After Roll: " + die2.TopSide);
            die2.Roll();
            Console.WriteLine("Top Side After Roll: " + die2.TopSide);
            die2.Roll();
            Console.WriteLine("Top Side After Roll: " + die2.TopSide);

            #endregion
        }
    }
}
