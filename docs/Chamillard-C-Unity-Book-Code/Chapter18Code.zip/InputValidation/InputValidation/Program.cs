﻿using System;

namespace InputValidation
{
    /// <summary>
    /// Demonstrates exception handling
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Demonstrates exception handling for input validation
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            //try
            //{
            //    // get numerator and denominator
            //    Console.Write("Enter numerator: ");
            //    float numerator = float.Parse(Console.ReadLine());
            //    Console.Write("Enter denominator: ");
            //    float denominator = float.Parse(Console.ReadLine());

            //    // calculate and display result
            //    float result = numerator / denominator;
            //    Console.WriteLine("Result of division is: " + result);
            //}
            //catch (FormatException fe)
            //{
            //    Console.WriteLine("Invalid input!");
            //}

            //bool valid = false;
            //while (!valid)
            //{
            //    try
            //    {
            //        // prompt for and get GPA
            //        Console.Write("Please enter a GPA (0.0-4.0): ");
            //        float gpa = float.Parse(Console.ReadLine());

            //        // loop for a valid GPA
            //        while (gpa < 0.0 || gpa > 4.0)
            //        {
            //            // print error message and get new GPA
            //            Console.WriteLine("Invalid entry! GPA must be between " +
            //                "0.0 and 4.0.");
            //            Console.WriteLine();
            //            Console.Write("Please enter a GPA (0.0-4.0): ");
            //            gpa = float.Parse(Console.ReadLine());
            //        }

            //        valid = true;
            //    }
            //    catch (FormatException fe)
            //    {
            //        Console.WriteLine("Invalid entry! GPA must be a number.");
            //        Console.WriteLine();
            //    }
            //}

            //			bool valid = false;
            //			while (!valid)
            //          {
            //				try
            //              {
            //			    	// prompt for and get GPA
            //			        Console.Write("Please enter a GPA (0.0-4.0): ");
            //			        float gpa = float.Parse(Console.ReadLine());
            //
            //			        // check for valid range
            //			        if (gpa < 0.0 || gpa > 4.0)
            //                  {
            //			        	Console.WriteLine("Invalid entry! GPA must be between " +
            //			            	"0.0 and 4.0.");
            //			        	Console.WriteLine();
            //			        }
            //                  else
            //                  {
            //			            valid = true;
            //			        }
            //			    }
            //              catch (FormatException fe)
            //              {
            //			    	Console.WriteLine("Invalid entry! GPA must be a number.");
            //			    	Console.WriteLine();
            //			    }
            //			}

            //    Console.WriteLine();

            // prompt for and read in date
            Console.Write("Enter date as mm/dd/yyyy: ");
            string date = Console.ReadLine();

            // count slashes
            int slashCount = 0;
            string tempString = date;
            while (tempString.IndexOf('/') != -1)
            {
                slashCount++;
                tempString = tempString.Substring(tempString.IndexOf('/') + 1);
            }

            // throw exception for wrong number of slashes
            if (slashCount != 2)
            {
                Console.WriteLine();
                throw new ApplicationException("Invalid date format entered");
            }
        }
    }
}
