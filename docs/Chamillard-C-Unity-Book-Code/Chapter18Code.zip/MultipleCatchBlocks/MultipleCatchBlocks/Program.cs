﻿using System;

namespace MultipleCatchBlocks
{
    /// <summary>
    /// Demonstrates multiple catch blocks
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Demonstrates multiple catch blocks
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            bool valid = false;
            while (!valid)
            {
                try
                {
                    // prompt for and get GPA
                    Console.Write("Enter a GPA (0.0-4.0): ");
                    double gpa = Double.Parse(Console.ReadLine());

                    // check for valid range
                    if (gpa < 0.0 || gpa > 4.0)
                    {
                        Console.WriteLine("Invalid entry! GPA must be between " +
                            "0.0 and 4.0.");
                        Console.WriteLine();
                    }
                    else
                    {
                        valid = true;
                    }
                }
                catch (FormatException fe)
                {
                    Console.WriteLine("Invalid entry! GPA must be a number.");
                    Console.WriteLine();
                }
                catch (OverflowException oe)
                {
                    Console.WriteLine("Invalid entry! GPA must be between " +
                        "0.0 and 4.0.");
                    Console.WriteLine();
                }
            }
        }
    }
}
