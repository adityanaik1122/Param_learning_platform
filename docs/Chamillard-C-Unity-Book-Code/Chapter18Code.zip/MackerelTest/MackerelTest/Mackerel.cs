﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MackerelTest
{	
	/// <summary>
	/// A mackerel
	/// </summary>
	class Mackerel
    {		
		#region Fields

		int length = 5;
		int weight = 5;
		int damage = 10;

		#endregion

		#region Constructors

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="length">the length of the mackerel</param>
		/// <param name="weight">the weight of the mackerel</param>
		/// <param name="damage">the damage for the mackerel</param>
		public Mackerel(int length, int weight, int damage)
        {
			this.length = length;
			this.weight = weight;
			this.damage = damage;
		}

		#endregion

		#region Properties

		/// <summary>
		/// Gets the length of the mackerel
		/// </summary>
		public int Length
        {
			get { return length; }
		}

		/// <summary>
		/// Gets the weight of the mackerel
		/// </summary>
		public int Weight
        {
			get { return weight; }
		}

		/// <summary>
		/// Gets the damage for the mackerel
		/// </summary>
		public int Damage
        {
			get { return damage; }
		}

		#endregion

		#region Public methods

		/// <summary>
		/// Standard equals comparison
		/// </summary>
		/// <param name="obj">the object to compare to</param>
		/// <returns>true if the objects are equal, false otherwise</returns>
		public override bool Equals(object obj)
        {
			return Equals(obj as Mackerel);

            #region deprecated code

            //// comparison to a null object returns false
            //if (obj == null)
            //{
            //    return false;
            //}

            //// if the parameter can't be cast to Mackerel return false
            //Mackerel objMackerel = obj as Mackerel;
            //if (objMackerel == null)
            //{
			//    return false;
			//}

			//// compare properties
			//return (Length == objMackerel.Length) &&
			//    (Weight == objMackerel.Weight) &&
			//    (Damage == objMackerel.Damage);

			#endregion
		}

		/// <summary>
		/// Type-specific equals comparison
		/// </summary>
		/// <param name="mackerel">the mackerel to compare to</param>
		/// <returns>true if the mackerels are equal, false otherwise</returns>
		public bool Equals(Mackerel mackerel)
        {			
			// comparison to a null mackerel returns false
			if (mackerel == null)
            {
				return false;
			}

			// compare properties
			return (Length == mackerel.Length) &&
				(Weight == mackerel.Weight) &&
				(Damage == mackerel.Damage);
		}

		/// <summary>
		/// Calculates a hash code for the mackerel
		/// </summary>
		/// <returns>the hash code</returns>
		public override int GetHashCode()
        {
			const int HashMultiplier = 31;
			int hash = length;
			hash = hash * HashMultiplier + weight;
			hash = hash * HashMultiplier + damage;
			return hash;
		}

		#endregion
	}
}