﻿using System;

namespace MackerelTest
{
    /// <summary>
    /// Tests the Equals methods
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Tests the Equals methods
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            Mackerel m1 = new Mackerel(10, 5, 1);

            // equal to m1
            Mackerel m2 = new Mackerel(10, 5, 1);

            // different length from m1
            Mackerel m3 = new Mackerel(20, 5, 1);

            // different damage from m1
            Mackerel m4 = new Mackerel(10, 15, 1);

            // different weight from m1
            Mackerel m5 = new Mackerel(10, 5, 11);

            // comparison to null object
            if (!m1.Equals(null))
            {
                Console.WriteLine("Comparison to null object passed");
            }
            else
            {
                Console.WriteLine("COMPARISON TO NULL OBJECT FAILED");
            }

            // comparison to non-Mackerel object
            if (!m1.Equals("Bob"))
            {
                Console.WriteLine("Comparison to non-mackerel object passed");
            }
            else
            {
                Console.WriteLine("COMPARISON TO NON-MACKEREL OBJECT FAILED");
            }

            // equal to m1
            if (m1.Equals(m2))
            {
                Console.WriteLine("Comparison to mackerel with same properties passed");
            }
            else
            {
                Console.WriteLine("COMPARISON TO MACKEREL WITH SAME PROPERTIES FAILED");
            }

            // different length from m1
            if (!m1.Equals(m3))
            {
                Console.WriteLine("Comparison to mackerel with different length passed");
            }
            else
            {
                Console.WriteLine("COMPARISON TO MACKEREL WITH DIFFERENT LENGTH FAILED");
            }

            // different damage from m1
            if (!m1.Equals(m4))
            {
                Console.WriteLine("Comparison to mackerel with different weight passed");
            }
            else
            {
                Console.WriteLine("COMPARISON TO MACKEREL WITH DIFFERENT WEIGHT FAILED");
            }

            // different weight from m1
            if (!m1.Equals(m4))
            {
                Console.WriteLine("Comparison to mackerel with different damage passed");
            }
            else
            {
                Console.WriteLine("COMPARISON TO MACKEREL WITH DIFFERENT DAMAGE FAILED");
            }
        }
    }
}