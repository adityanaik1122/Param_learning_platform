﻿using System;

namespace CustomException
{	
	/// <summary>
	/// A custom exception class
	/// </summary>
	public class MyException : Exception
    {
	}
}
