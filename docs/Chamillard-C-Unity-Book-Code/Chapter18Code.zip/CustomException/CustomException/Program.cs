﻿namespace CustomException
{
    /// <summary>
    /// Tests throwing a custom exception
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Throws a custom exception
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            throw new MyException();
        }
    }
}