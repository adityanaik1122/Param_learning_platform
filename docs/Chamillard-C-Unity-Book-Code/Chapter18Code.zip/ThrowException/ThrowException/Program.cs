﻿using System;

namespace ThrowException
{
    /// <summary>
    /// Demonstrates throwing an exception
    /// </summary>

    internal class Program
    {
        /// <summary>
        /// Demonstrates throwing an exception
        /// </summary>
        /// <param name="args">command-line args</param>

        static void Main(string[] args)
        {
            // prompt for and read in date
            Console.Write("Enter date as mm/dd/yyyy: ");
            string date = Console.ReadLine();

            // count slashes
            int slashCount = 0;
            string tempString = date;
            while (tempString.IndexOf('/') != -1)
            {
                slashCount++;
                tempString = tempString.Substring(tempString.IndexOf('/') + 1);
            }

            // throw exception for wrong number of slashes
            if (slashCount != 2)
            {
                Console.WriteLine();
                throw new ApplicationException("Invalid date format entered");
            }
        }
    }
}
