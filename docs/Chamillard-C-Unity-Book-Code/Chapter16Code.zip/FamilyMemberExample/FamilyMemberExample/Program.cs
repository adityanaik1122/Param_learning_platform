﻿using System.Collections.Generic;

namespace FamilyMemberExample
{
    /// <summary>
    /// Demonstrates inheritance
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Demonstrates inheritance
        /// </summary>
        /// <param name="args">command-line args</param>
        static void Main(string[] args)
        {
            List<FamilyMember> familyMembers = new List<FamilyMember>();

            familyMembers.Add(new FamilyMember(69, 185));
            familyMembers.Add(new Gamer(70, 200));
            familyMembers.Add(new Geek(71, 165));

            foreach (FamilyMember familyMember in familyMembers)
            {
                familyMember.HaveFun();
            }
        }
    }
}